Deucalion Board rev.0.1 (2019-02-13)
(c) andreika, 2019
https://github.com/andreika-git/deucalion

Layers:
Top Silkscreen:    deucalion.gto
Top SolderMask:    deucalion.gts
Top Copper:        deucalion.gtl
Bottom Copper:     deucalion.gbl
Bottom SolderMask: deucalion.gbs
Bottom Silkscreen: deucalion.gbo
Keepout:           deucalion.gko
NC Drill:          deucalion.drl
